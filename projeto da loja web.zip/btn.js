alert("oops o publicar jogos e apps n esta funcionando ainda")
